# Discord Developer Portal'dan aldigin bot tokenini buraya yaz.
# Gercek tokenini GitHub'a yukleme!
TOKEN = ""

DATABASE = "data.db"
AUCTION_INTERVAL_MINUTES = 5
BONUS_PER_WIN = 10
