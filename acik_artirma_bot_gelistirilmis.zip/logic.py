import os
import sqlite3
from datetime import datetime


class DatabaseManager:
    def __init__(self, database="data.db"):
        self.database = database

    def connect(self):
        conn = sqlite3.connect(self.database)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def create_tables(self):
        with self.connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    user_name TEXT NOT NULL,
                    points INTEGER NOT NULL DEFAULT 0
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS prizes (
                    prize_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    image TEXT NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0,
                    special INTEGER NOT NULL DEFAULT 0,
                    price INTEGER NOT NULL DEFAULT 0
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS winners (
                    user_id INTEGER NOT NULL,
                    prize_id INTEGER NOT NULL,
                    win_time TEXT NOT NULL,
                    UNIQUE(user_id, prize_id),
                    FOREIGN KEY(user_id) REFERENCES users(user_id),
                    FOREIGN KEY(prize_id) REFERENCES prizes(prize_id)
                )
            """)

            user_cols = {r[1] for r in conn.execute("PRAGMA table_info(users)")}
            if "points" not in user_cols:
                conn.execute("ALTER TABLE users ADD COLUMN points INTEGER NOT NULL DEFAULT 0")
            prize_cols = {r[1] for r in conn.execute("PRAGMA table_info(prizes)")}
            if "special" not in prize_cols:
                conn.execute("ALTER TABLE prizes ADD COLUMN special INTEGER NOT NULL DEFAULT 0")
            if "price" not in prize_cols:
                conn.execute("ALTER TABLE prizes ADD COLUMN price INTEGER NOT NULL DEFAULT 0")

    def add_user(self, user_id, user_name):
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT OR IGNORE INTO users(user_id, user_name) VALUES (?, ?)",
                (user_id, user_name)
            )
            return cur.rowcount > 0

    def user_exists(self, user_id):
        with self.connect() as conn:
            return conn.execute("SELECT 1 FROM users WHERE user_id=?", (user_id,)).fetchone() is not None

    def get_users(self):
        with self.connect() as conn:
            return [r[0] for r in conn.execute("SELECT user_id FROM users")]

    def get_points(self, user_id):
        with self.connect() as conn:
            row = conn.execute("SELECT points FROM users WHERE user_id=?", (user_id,)).fetchone()
            return row[0] if row else 0

    def add_prize(self, image, special=False, price=0):
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO prizes(image, special, price) VALUES (?, ?, ?)",
                (image, int(special), price)
            )
            return cur.lastrowid

    def get_random_prize(self):
        with self.connect() as conn:
            return conn.execute(
                "SELECT prize_id, image FROM prizes WHERE used=0 AND special=0 ORDER BY RANDOM() LIMIT 1"
            ).fetchone()

    def get_prize_image(self, prize_id):
        with self.connect() as conn:
            row = conn.execute("SELECT image FROM prizes WHERE prize_id=?", (prize_id,)).fetchone()
            return row[0] if row else None

    def mark_prize_used(self, prize_id):
        with self.connect() as conn:
            conn.execute("UPDATE prizes SET used=1 WHERE prize_id=?", (prize_id,))

    def claim_prize(self, user_id, prize_id, bonus):
        # Islem tek transaction icinde yapilir; ayni odul en fazla 3 kez kazanilir.
        with self.connect() as conn:
            prize = conn.execute(
                "SELECT used, special FROM prizes WHERE prize_id=?", (prize_id,)
            ).fetchone()
            if not prize or prize[0] or prize[1]:
                return "inactive"
            if conn.execute(
                "SELECT 1 FROM winners WHERE user_id=? AND prize_id=?", (user_id, prize_id)
            ).fetchone():
                return "already_won"
            count = conn.execute(
                "SELECT COUNT(*) FROM winners WHERE prize_id=?", (prize_id,)
            ).fetchone()[0]
            if count >= 3:
                return "full"
            conn.execute(
                "INSERT INTO winners(user_id, prize_id, win_time) VALUES (?, ?, ?)",
                (user_id, prize_id, datetime.now().isoformat(timespec="seconds"))
            )
            conn.execute("UPDATE users SET points=points+? WHERE user_id=?", (bonus, user_id))
            return "won"

    def get_special_prizes(self):
        with self.connect() as conn:
            return conn.execute(
                "SELECT prize_id, image, price FROM prizes WHERE special=1 AND used=0 ORDER BY prize_id"
            ).fetchall()

    def buy_special_prize(self, user_id, prize_id):
        with self.connect() as conn:
            user = conn.execute("SELECT points FROM users WHERE user_id=?", (user_id,)).fetchone()
            if not user:
                return "no_user"
            item = conn.execute(
                "SELECT price FROM prizes WHERE prize_id=? AND special=1 AND used=0",
                (prize_id,)
            ).fetchone()
            if not item:
                return "no_item"
            if user[0] < item[0]:
                return "not_enough"
            conn.execute("UPDATE users SET points=points-? WHERE user_id=?", (item[0], user_id))
            conn.execute("UPDATE prizes SET used=1 WHERE prize_id=?", (prize_id,))
            return "bought"

    def get_rating(self):
        with self.connect() as conn:
            return conn.execute("""
                SELECT users.user_name, COUNT(winners.prize_id) AS prize_count
                FROM winners JOIN users ON users.user_id=winners.user_id
                GROUP BY users.user_id, users.user_name
                ORDER BY prize_count DESC LIMIT 10
            """).fetchall()


def hide_img(source_path, output_path):
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError("Gorsel bulaniklastirmak icin opencv-python kur: pip install opencv-python") from exc
    image = cv2.imread(source_path)
    if image is None:
        raise ValueError(f"Resim okunamadi: {source_path}")
    blurred = cv2.GaussianBlur(image, (15, 15), 0)
    pixelated = cv2.resize(blurred, (30, 30), interpolation=cv2.INTER_NEAREST)
    pixelated = cv2.resize(pixelated, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_NEAREST)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    cv2.imwrite(output_path, pixelated)
