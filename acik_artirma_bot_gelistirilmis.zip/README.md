# Acik Artirma Botu

Discord.py ve SQLite ile calisan resim acik artirma botu.

## Kurulum
1. Python 3.10+ kur.
2. Terminalde proje klasorune gir.
3. `pip install -r requirements.txt` komutunu calistir.
4. `config.py` icindeki `TOKEN` alanina Discord bot tokenini yaz.
5. Discord Developer Portal'da Message Content Intent'i etkinlestir.
6. Odul resimlerini `img/` klasorune koy.
7. `python bot.py` komutuyla baslat.

## Kullanici komutlari
- `!start` - Kayit ol.
- `!points` - Bonus puanini gor.
- `!shop` - Ozel resim magazasini listele.
- `!buy RESIM_ID` - Puanla ozel resim satin al.

## Yonetici komutlari
- `!addimage` + resim eki - Normal odul ekle.
- `!addspecial PUAN` + resim eki - Puanli magazaya ozel resim ekle.
- `!setbonus SAYI` - Kazanan basina bonus puanini ayarla.
- `!setinterval DAKIKA` - Acik artirma araligini ayarla.
- `!rating` - Kazananlar siralamasi.
- `!helpadmin` - Yonetici komutlari.

Her acik artirmada ilk 3 farkli kullanici odulu kazanabilir. Kazananlara bonus puan verilir.

## Guvenlik
`config.py` dosyasi `.gitignore` icindedir. Gercek bot tokenini GitHub'a yukleme.
Token yanlislikla paylasildiysa Discord Developer Portal'dan yenile.

Mevcut eski SQLite veritabanina yeni alanlar otomatik eklenir. Yine de once `data.db` dosyanin yedegini al.
