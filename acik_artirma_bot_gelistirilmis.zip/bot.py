import os
import re
import discord
from discord.ext import commands, tasks

import config
from logic import DatabaseManager, hide_img

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)
manager = DatabaseManager(config.DATABASE)


class AuctionView(discord.ui.View):
    def __init__(self, prize_id):
        super().__init__(timeout=None)
        self.prize_id = prize_id

    @discord.ui.button(label="Al!", style=discord.ButtonStyle.success)
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        result = manager.claim_prize(
            interaction.user.id, self.prize_id, config.BONUS_PER_WIN
        )
        if result == "won":
            image_name = manager.get_prize_image(self.prize_id)
            image_path = os.path.join("img", image_name) if image_name else ""
            kwargs = {"content": f"Tebrikler! Resmi kazandin ve {config.BONUS_PER_WIN} bonus puan aldın."}
            if image_path and os.path.isfile(image_path):
                kwargs["file"] = discord.File(image_path)
            await interaction.response.send_message(**kwargs, ephemeral=True)
        elif result == "already_won":
            await interaction.response.send_message("Bu resmi zaten kazandin.", ephemeral=True)
        elif result == "full":
            await interaction.response.send_message("Bu odulun 3 kazanan kontenjani doldu.", ephemeral=True)
        else:
            await interaction.response.send_message("Bu acik artirma artik aktif degil.", ephemeral=True)


@bot.command()
async def start(ctx):
    if manager.add_user(ctx.author.id, ctx.author.name):
        await ctx.send("Kayit tamamlandi! Yeni acik artirmalari DM uzerinden alacaksin.")
    else:
        await ctx.send("Zaten kayitlisin!")


@bot.command()
async def points(ctx):
    if not manager.user_exists(ctx.author.id):
        await ctx.send("Once !start komutuyla kayit ol.")
        return
    await ctx.send(f"Bonus puanin: **{manager.get_points(ctx.author.id)}**")


@bot.command()
async def shop(ctx):
    items = manager.get_special_prizes()
    if not items:
        await ctx.send("Magazada su anda ozel resim yok.")
        return
    lines = [f"#{pid} - {name} - {price} puan" for pid, name, price in items]
    await ctx.send("**Ozel resim magazasi**\n" + "\n".join(lines) + "\nSatin almak icin: !buy RESIM_ID")


@bot.command()
async def buy(ctx, prize_id: int):
    result = manager.buy_special_prize(ctx.author.id, prize_id)
    if result == "bought":
        image_name = manager.get_prize_image(prize_id)
        path = os.path.join("img", image_name) if image_name else ""
        if path and os.path.isfile(path):
            await ctx.send("Satin alma basarili!", file=discord.File(path))
        else:
            await ctx.send("Satin alma basarili; ancak resim dosyasi bulunamadi.")
    elif result == "no_user":
        await ctx.send("Once !start komutuyla kayit ol.")
    elif result == "no_item":
        await ctx.send("Bu ID ile satilik ozel resim bulunamadi.")
    else:
        await ctx.send("Yeterli bonus puanin yok.")


async def save_attachment(ctx, special=False, price=0):
    if not ctx.message.attachments:
        await ctx.send("Komutla birlikte bir resim dosyasi eklemelisin.")
        return
    attachment = ctx.message.attachments[0]
    if not attachment.content_type or not attachment.content_type.startswith("image/"):
        await ctx.send("Lutfen gecerli bir resim dosyasi ekle.")
        return
    os.makedirs("img", exist_ok=True)
    filename = os.path.basename(attachment.filename)
    await attachment.save(os.path.join("img", filename))
    prize_id = manager.add_prize(filename, special=special, price=price)
    await ctx.send(f"Resim eklendi. ID: **{prize_id}**")


@bot.command()
@commands.has_permissions(administrator=True)
async def addimage(ctx):
    await save_attachment(ctx)


@bot.command()
@commands.has_permissions(administrator=True)
async def addspecial(ctx, price: int):
    if price < 1:
        await ctx.send("Fiyat en az 1 puan olmali.")
        return
    await save_attachment(ctx, special=True, price=price)


@bot.command()
@commands.has_permissions(administrator=True)
async def setbonus(ctx, amount: int):
    if amount < 0:
        await ctx.send("Bonus negatif olamaz.")
        return
    path = "config.py"
    content = open(path, encoding="utf-8").read()
    if re.search(r"(?m)^BONUS_PER_WIN\s*=", content):
        content = re.sub(r"(?m)^BONUS_PER_WIN\s*=.*$", f"BONUS_PER_WIN = {amount}", content)
    else:
        content += f"\nBONUS_PER_WIN = {amount}\n"
    open(path, "w", encoding="utf-8").write(content)
    config.BONUS_PER_WIN = amount
    await ctx.send(f"Kazanan bonusu {amount} puan olarak ayarlandi.")


@bot.command()
@commands.has_permissions(administrator=True)
async def setinterval(ctx, minutes: int):
    if minutes < 1:
        await ctx.send("Aralik en az 1 dakika olmali.")
        return
    config.AUCTION_INTERVAL_MINUTES = minutes
    send_auction.change_interval(minutes=minutes)
    path = "config.py"
    content = open(path, encoding="utf-8").read()
    if re.search(r"(?m)^AUCTION_INTERVAL_MINUTES\s*=", content):
        content = re.sub(r"(?m)^AUCTION_INTERVAL_MINUTES\s*=.*$", f"AUCTION_INTERVAL_MINUTES = {minutes}", content)
    else:
        content += f"\nAUCTION_INTERVAL_MINUTES = {minutes}\n"
    open(path, "w", encoding="utf-8").write(content)
    await ctx.send(f"Acik artirma araligi {minutes} dakika oldu.")


@bot.command()
@commands.has_permissions(administrator=True)
async def rating(ctx):
    rows = manager.get_rating()
    if not rows:
        await ctx.send("Henuz kazanan yok.")
        return
    await ctx.send("**Kazananlar**\n" + "\n".join(
        f"{i}. {name}: {count} odul" for i, (name, count) in enumerate(rows, 1)
    ))


@bot.command()
@commands.has_permissions(administrator=True)
async def helpadmin(ctx):
    await ctx.send(
        "**Yonetici komutlari**\n"
        "`!addimage` + resim eki - Normal odul ekle\n"
        "`!addspecial PUAN` + resim eki - Ozel resim ekle\n"
        "`!setbonus SAYI` - Kazanan bonusunu ayarla\n"
        "`!setinterval DAKIKA` - Acik artirma araligini ayarla\n"
        "`!rating` - Kazananlar siralamasi"
    )


@tasks.loop(minutes=config.AUCTION_INTERVAL_MINUTES)
async def send_auction():
    prize = manager.get_random_prize()
    if not prize:
        return
    prize_id, image_name = prize
    source = os.path.join("img", image_name)
    hidden = os.path.join("hidden_img", image_name)
    if not os.path.isfile(source):
        print(f"Resim bulunamadi: {source}")
        manager.mark_prize_used(prize_id)
        return
    try:
        hide_img(source, hidden)
    except Exception as error:
        print(f"Onizleme olusturulamadi: {error}")
        return

    view = AuctionView(prize_id)
    sent = 0
    for user_id in manager.get_users():
        try:
            user = await bot.fetch_user(user_id)
            await user.send(
                "Yeni bir acik artirma basladi! Ilk 3 kisi odulu kazanir.",
                file=discord.File(hidden),
                view=view,
            )
            sent += 1
        except (discord.Forbidden, discord.NotFound, discord.HTTPException) as error:
            print(f"DM gonderilemedi ({user_id}): {error}")
    if sent:
        manager.mark_prize_used(prize_id)


@bot.event
async def on_ready():
    manager.create_tables()
    print(f"{bot.user} olarak giris yapildi!")
    if not send_auction.is_running():
        send_auction.start()


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("Bu komut icin yonetici yetkisi gerekiyor.")
    elif isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)):
        await ctx.send("Komut eksik veya hatali. !help yazabilirsin.")
    elif isinstance(error, commands.CommandNotFound):
        return
    else:
        print(f"Komut hatasi: {error}")
        await ctx.send("Komut calistirilirken hata olustu.")


if not config.TOKEN:
    raise RuntimeError("config.py dosyasindaki TOKEN alanina Discord bot tokenini ekle.")
manager.create_tables()
bot.run(config.TOKEN)
